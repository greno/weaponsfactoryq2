This zip file contains all of the Weapons Factory 4.25 NT server related files.

For complete info on how to set up a Weapons Factory server, visit the
Weapons Factory web site at http://www.captured.com/weaponsfactory/quake2/
and look at the Server Files/Setup section.

There are many new changes for server administrators that you should 
visit the web site and review the Server Files/Setup page.

Notes:
This version DOES NOT HAVE ERASER BOTS. There should be a second release soon
With eraser bots for those that want them..

Also MOCK users will have to download the 4.25 ref database. You will then 
have to import these classfiles..

Thanks to all those that helped beta test ,report bugs and post suggestions..