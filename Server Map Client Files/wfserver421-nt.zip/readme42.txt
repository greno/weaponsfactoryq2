This zip file contains all of the Weapons Factory 4.2 server related files.

For complete info on how to set up a Weapons Factory server, visit the
Weapons Factory web site at http://www.captured.com/weaponsfactory and
look at the Server Setup section.

For those of you who are upgrading, make sure you make a copy of your
server.cfg and wfserver.ini files before installing these files.  There are
so many new changes for server administrators that you should visit the web
site and review the Server Setup page.

There are some new files included in this release to support the built in
Weapons Factory eraser bot, including a few .DLLs and .CFG files. If you
plan on running bots on your server, please visit the WF Eraser Bot page
on the WF web site.  You should also look at the eraser_readme.txt and
wferaser42.htm files.  The fastest way to get bots working on your server
is to run this command in the console window:

  bot_num 4

The number at the end of the command is the number of bots to add. They will
automatically divide themselves into separate teams.
